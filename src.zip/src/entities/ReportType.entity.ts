export enum ReportType {
    PENCEGAHAN = 'pencegahan',
    EXISTING = 'eksisting',
    DAMPAK = 'dampak'
}
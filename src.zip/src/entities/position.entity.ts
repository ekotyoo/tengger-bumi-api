export interface Position {
    latitude: number
    longitude: number
}